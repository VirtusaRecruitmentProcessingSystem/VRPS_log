package com.vrps.authentication;

import java.util.Scanner;
//import org.apache.log4j.Logger;

import org.apache.log4j.Logger;

import com.virtusa.dao.TrDAOImp;


public class AuthenticationView {
	Logger logger=Logger.getLogger(AuthenticationView.class.getName());

//public static void main(String[] args) {
	
	// try putting Login model for username,password and then retrieving data from it
		public boolean main(int option) {
		// TODO Auto-generated method stub
			logger.info("--- In AuthenticationView main method called---");

		String username=null;
		String password=null;
		System.out.println();
		Scanner scanner1=new Scanner(System.in);

		System.out.print("Enter UserName:");
		logger.info("Enter UserName:");
		String username1=scanner1.next();
		System.out.print("Enter Password:");
		logger.info("Enter Password:");
		String password1=scanner1.next();
	
		UserAuthentication auth=new UserAuthentication();
		
		 boolean result=auth.Verification(username1,password1,option );		 
		 return result;
	// System.out.print(result);
	}

}

