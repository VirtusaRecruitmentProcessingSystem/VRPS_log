package com.virtusa.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.virtusa.integrate.ConnectionManager;
import com.virtusa.model.ASLModel;
import com.virtusa.model.ApplicationModel;

/*
 * Skeleton at Front End
 * ApplicationModel(String fname, String mname, String lname, Date datex, String phone,String qualification, String email, int passYear,int jobId,
			float percentage, int experience,String address,List<String> skills)
 */

/*
 * Schema at DB perspective
 * 
 * Name            Null     Type         
--------------- -------- ------------ 
REFERENCE_ID    NOT NULL NUMBER       
FIRST_NAME      NOT NULL VARCHAR2(40) 
MIDDLE_NAME     NOT NULL VARCHAR2(40) 
LAST_NAME       NOT NULL VARCHAR2(40) 
DATE_OF_BIRTH   NOT NULL DATE         
PHONE_NUMBER             VARCHAR2(40) 
ADDRESS                  VARCHAR2(40) 
QUALIFICATION   NOT NULL VARCHAR2(40) 
EMAIL_ID        NOT NULL VARCHAR2(40) 
YEAR_OF_PASSING NOT NULL NUMBER(4)    
PERCENTAGE               NUMBER(4,2)  
JOBSEEKER_ID             NUMBER       
EXPERIENCE               NUMBER 
 * 
 */

public class ApplicationDAO {
	Logger logger=Logger.getLogger(ApplicationDAO.class.getName());


	public void ApplicationStorage(ApplicationModel application) {

		logger.info("--- In ApplicationDAO ApplicationStorage method called---");

		String Fname=application.getFname();
		String Mname=application.getMname();
		String Lname=application.getLname();
		Date datex=application.getDatex();
		String Phone=application.getPhone();
		String qualification=application.getQualification();
		String email=application.getEmail();
		int passYear=application.getPassYear();
		int jobpostId=application.getJobpostId();
		float percentage=application.getPercentage();
		int experience=application.getExperience();
		String address=application.getAddress();
		List<String> skills=application.getSkills();
		
		SimpleDateFormat formatter = new SimpleDateFormat("dd-mm-yyyy");
		 String strDate = formatter.format(datex);
		
		
		try(      Connection conn=ConnectionManager.openConnection();   )
		{
			logger.info("---connection created sucessfully---");
			String query="insert into applications values(?,?,?,?,?,?,?,?,?,?,/job seeejker id/,?,?)";			
			PreparedStatement st=conn.prepareStatement(query);
			
			st.setString(1, Fname);
			st.setString(2,Mname );
			st.setString(3, Lname );
			st.setString(4,strDate);
			st.setString(5, Phone);
			st.setString(6, address);
			st.setString(7, qualification);
			st.setString(8, email);
			st.setInt(9,passYear);
			st.setFloat(10,percentage );
			st.setInt(11, experience);
			st.setInt(12, jobpostId);
			
			int response=st.executeUpdate();
			//////////////
			
			//retrieve reference id from mysql
			
			skills.forEach((o)->{
				try {
					String query2="insert into application_skills values(REFERENCE_ID.CURRVAL,?)";//cha
					PreparedStatement state=conn.prepareStatement(query2);
				state.setString(1,o);
				
				int inside=state.executeUpdate();
					if (inside>0) {
							System.out.println("appDAo-----Skills Added into DAO succesfully");
								}
					else
							System.out.println("appDAo-------Skil ls DAO not DAO going DAO yaaaaa");
				}
				catch(SQLException s) {
					System.out.println("Error at adding Skills");
					logger.error(s);
				}
			});
			////////
			
			if(response>0)
				System.out.println("DOne!! Applied SuccessFully-----Stored Succesfully");
		}
		catch(ClassNotFoundException | SQLException e) {
			logger.error(e);

		}
	}

	/*
	 *Applications table Schema 
	 * 		REFERENCE_ID    NOT NULL NUMBER       
			FIRST_NAME      NOT NULL VARCHAR2(40) 
			MIDDLE_NAME     NOT NULL VARCHAR2(40) 
			LAST_NAME       NOT NULL VARCHAR2(40) 
			DATE_OF_BIRTH   NOT NULL DATE         
			PHONE_NUMBER             VARCHAR2(40) 
			ADDRESS                  VARCHAR2(40) 
			QUALIFICATION   NOT NULL VARCHAR2(40) 
			EMAIL_ID        NOT NULL VARCHAR2(40) 
			YEAR_OF_PASSING NOT NULL NUMBER(4)    
			PERCENTAGE               NUMBER(4,2)  
			JOBSEEKER_ID             NUMBER       
			EXPERIENCE               NUMBER  
	 * 
	 */
	
	
	public List<ApplicationModel> retrieveAllApplications() {
		logger.info("--- In ApplicationDAO retrieveAllApplications method called---");

		String fname;
		String mname;
		String lname;
		Date datex;
		int passYear;
		int experience;
		String address;
		String qualification;
		String email;
		String phone;
		float percentage;
		int jobpostId;
		int jobseekerID,REFERENCE_ID;
		List<String> skills=new ArrayList<String>();
		
		List<ApplicationModel> dataUntouched=new ArrayList<>();
		
		try(Connection retrieve=ConnectionManager.openConnection();){
			
		String retrieveString="select * from applications";
		PreparedStatement retriveStatement=retrieve.prepareStatement(retrieveString);
		
		ResultSet retriveSet=retriveStatement.executeQuery();
		
		while(retriveSet.next()) {
	     
			jobseekerID=retriveSet.getInt("JOBSEEKER_ID");
			fname=retriveSet.getString("FIRST_NAME");
			mname=retriveSet.getString("MIDDLE_NAME");
			lname=retriveSet.getString("LAST_NAME");
			datex=retriveSet.getDate("DATE_OF_BIRTH");
			passYear=retriveSet.getInt("YEAR_OF_PASSING");
			experience=retriveSet.getInt("EXPERIENCE");
			address=retriveSet.getString("ADDRESS");
			qualification=retriveSet.getString("QUALIFICATION");
			email=retriveSet.getString("EMAIL_ID");
			phone=retriveSet.getString("PHONE_NUMBER");
			percentage=retriveSet.getFloat("PERCENTAGE");
			jobpostId=retriveSet.getInt("JOBPOST_ID");
			REFERENCE_ID=retriveSet.getInt("REFERENCE_ID");
			
			/*
			
			String retrieveS="select skill from application_skills where REFERENCE_ID=?";
			retriveStatement=retrieve.prepareStatement(retrieveS);
			ResultSet skillResult=retriveStatement.executeQuery();
			
			while(skillResult.next()) {
				skills.add(skillResult.getString("SKILL"));
			}
			
			*/
			ApplicationModel appliedModel=new ApplicationModel(jobseekerID,fname, mname, lname, datex, phone,qualification, email, passYear,jobpostId,
					percentage, experience,address,skills,REFERENCE_ID);
			
			dataUntouched.add(appliedModel);

		}	
	}
		catch(Exception e) {	
			logger.error("error at applying dao");	}
		return dataUntouched;
}
	
	
	
}