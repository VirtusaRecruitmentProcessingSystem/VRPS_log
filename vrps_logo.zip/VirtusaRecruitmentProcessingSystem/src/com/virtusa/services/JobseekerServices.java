package com.virtusa.services;

import com.virtusa.model.JobseekerModel;

public interface JobseekerServices{
	public int JobseekerRegistration(JobseekerModel model);
	public void JobseekerLogin();
}
