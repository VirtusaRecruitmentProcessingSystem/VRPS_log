package com.virtusa.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.virtusa.dao.JobDAO;
import com.virtusa.entities.JobEntity;


/*
 * JOB_ID                NOT NULL NUMBER(10)   
DESIGNATION           NOT NULL VARCHAR2(40) 
REQUIRED_EXPERIENCE            NUMBER(2)    
REQUIRED_SKILLS                VARCHAR2(40) 
ELIGIBILITYPERCENTAGE          NUMBER(2,2) 
 */

public class JobServiceImpl implements jobServices {

	Logger logger=Logger.getLogger(JobServiceImpl.class.getName());

	@Override
	public void viewjobPosts() {
		logger.info("--viewjobPosts method --");

		JobDAO viewjobs=new JobDAO();
		viewjobs.viewallJobs();
		
		logger.info("--viewjobPosts method completed--");

	}

	@Override
	public void addJobPost()
	{
		logger.info("--addJobPost method --");

		 int jobId;
		 String designation;
		 int experience;
		 double eligibilityPercentage;
		 List<String> skills;

			Scanner input=new Scanner(System.in);
			
			System.out.println("-------------------");
			System.out.println("  Adding Job Post  ");
			logger.info("Adding Job Post");
			System.out.println("-------------------\n");
			System.out.println(" Enter Job ID:");
			logger.info("Enter Job ID:");

			jobId=input.nextInt();
			System.out.println(" Enter Job Role:");
			logger.info("Enter Job Role:");

			designation=input.next();
			
			System.out.println("\n1.Java\n2.SQL\n3.Data Science\n4.Testing\n5.Exit");
			
			skills=new ArrayList<String>();
			
			int choice;
			
			
			do {
			System.out.println(" Enter Required Skills:");
			logger.info("Enter Required Skills::");

			choice=input.nextInt();
			
			switch(choice) {
			case 1:skills.add("java");
					break;
			case 2:skills.add("sql");
					break;
			case 3:skills.add("data science");
					break;
			case 4:skills.add("testing");
					break;
			case 5: break;
			
			default:skills.add("c");
				}
			
			}while(choice!=5);

			
			System.out.println(" Enter Eligibility percentage:");
			logger.info("Enter Eligibility percentage:");

			eligibilityPercentage=input.nextDouble();
			System.out.println(" Enter years of experience:");
			logger.info("Enter years of experience:");

			experience=input.nextInt();
			
			

			JobEntity newjob=new JobEntity(jobId,designation,experience,eligibilityPercentage,skills);
			JobDAO addingJobPost=new JobDAO();
			addingJobPost.addJobPost(newjob);
			logger.info("--addJobPost method completed--");

	}

}
 
