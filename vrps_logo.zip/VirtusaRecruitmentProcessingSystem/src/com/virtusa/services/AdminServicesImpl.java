package com.virtusa.services;


import java.util.Scanner;

import org.apache.log4j.Logger;

import com.virtusa.controller.AdminController;
import com.virtusa.dao.AdminDAO;
import com.virtusa.dao.JobDAO;

public class AdminServicesImpl implements AdminServices
{
	Logger logger=Logger.getLogger(AdminServicesImpl.class.getName());

	AdminDAO adminDAO=new AdminDAO();

	@Override
	public void rate_comment() {
		logger.info("--rate_comment method --");

		//display all candidates one by one and give rating

		adminDAO.rate_comment();
		logger.info("--rate_comment method completed--");

	}

	@Override
	public void addJobPost() {
		logger.info("--addJobPost method--");
		jobServices js=new JobServiceImpl();
		js.addJobPost();
		logger.info("--addJobPost method completed--");

	}
	@Override
	public void deleteJobPost() {
		logger.info("--deleteJobPost method --");

		jobServices js=new JobServiceImpl();

		System.out.println("Enter jobPostID of JobPost to be deleted:");
		Scanner sx=new Scanner(System.in);
		int del=sx.nextInt();

		JobDAO delete=new JobDAO();
		delete.dropJobPost(del);
		logger.info("--deleteJobPost method completed--");

	}

}
