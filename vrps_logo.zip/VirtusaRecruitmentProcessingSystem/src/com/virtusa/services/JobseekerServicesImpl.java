package com.virtusa.services;

import org.apache.log4j.Logger;

import com.virtusa.dao.JobseekerDAO;
import com.virtusa.model.JobseekerModel;

public class JobseekerServicesImpl implements JobseekerServices{
	Logger logger=Logger.getLogger(JobseekerServicesImpl.class.getName());
int jobs_id;
	@Override
	public int JobseekerRegistration(JobseekerModel model) {
		logger.info("--- In JobseekerServicesImpl JobseekerRegistration method called---");
		// TODO Auto-generated method stub
		JobseekerDAO jdao=new JobseekerDAO();
		jobs_id=jdao.addJobSeeker(model);
		return jobs_id;
		//System.out.println("Added Succesfully");
	}

	@Override
	public void JobseekerLogin() {
		logger.info("--- In JobseekerServicesImpl JobseekerLogin method called---");

		// TODO Auto-generated method stub
		
	}

	public void viewStatus(int refId) {
		logger.info("--- In JobseekerServicesImpl viewStatus method called---");

		JobseekerDAO jdao=new JobseekerDAO();
		jdao.showStatus(refId);
	}
	
}
