package com.virtusa.view;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.virtusa.controller.ApplicationController;
import com.virtusa.controller.JobseekerController;

import com.virtusa.model.ApplicationModel;
import com.virtusa.model.JobseekerModel;
import com.virtusa.model.LoginModel;
import com.virtusa.ui.VRPSHome;

import com.virtusa.validation.JobseekerValidation;
import com.vrps.authentication.AuthenticationView;


/*
 * Name            Null     Type         
--------------- -------- ------------ 
FIRST_NAME      NOT NULL VARCHAR2(40) 
MIDDLE_NAME     NOT NULL VARCHAR2(40) 
LAST_NAME       NOT NULL VARCHAR2(40) 
DATE_OF_BIRTH   NOT NULL DATE         
PHONE_NUMBER             VARCHAR2(40) 
QUALIFICATION   NOT NULL VARCHAR2(40) 
EMAIL_ID        NOT NULL VARCHAR2(40) 
YEAR_OF_PASSING NOT NULL NUMBER(4)    
JOB_ID          NOT NULL NUMBER       
GRADPERCENTAGE  NOT NULL NUMBER(4,2)  
EXPERIENCE               NUMBER(2)
 */


public class JobseekerView {
//
	Logger logger=Logger.getLogger(JobseekerView.class.getName());
	static boolean flag=false;
Scanner scanner=new Scanner(System.in);
	int jobs_id;
	
	VRPSHome back=new VRPSHome();
	
	public void mainMenu() {
		logger.info("--- In JobseekerView mainMenu method called---");
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("\n1.JobSeeker Registration\n2.JobSeeker Login\n3.Back");
		int option=s.nextInt();
		
		JobseekerView js_view=new JobseekerView();
		if(option==1) {
			js_view.registerJobSeeker();
		}
		else if(option==2)
		{
			js_view.loginJobSeeker();
		}
		else if(option==3)
			back.main(null);
	}
	
	public void registerJobSeeker() {
		logger.info("--- In JobseekerView registerJobSeeker method called---");

		JobseekerValidation validator=new JobseekerValidation(); 		
		
		//////////////////////
		String firstName;
		boolean validfirstName=false;
		do {
		System.out.print("First Name:");
		logger.info("enter firstname");
		
		firstName=scanner.next();
		validfirstName=validator.validString(firstName);
		
		if(validfirstName==false)
		System.out.print("-------------Enter name in Alphabets only-------------\n");
		}
		while(!validfirstName);
		
		////////////////////////////
		String middleName;
		boolean validmiddleName=false;
		do {
		System.out.print("Middle Name:");
		logger.info("enter middlename");

		middleName=scanner.next();
		validmiddleName=validator.validString(middleName);
		
		if(validmiddleName==false)
		System.out.print("-------------Enter name in Alphabets only-------------\n");
		}
		while(!validmiddleName);
		////////////////////////////
		
		
		String lastName;
		boolean validlastName=false;
		do {
		System.out.print("Last Name:");
		logger.info("enter lastname");

		lastName=scanner.next();
		validlastName=validator.validString(lastName);
		
		if(validlastName==false)
		System.out.print("-------------Enter name in Alphabets only-------------\n");
		}
		while(!validlastName);
		
		
		////////////////////////////

		Date datex=null;		
		do {
		System.out.println("\nEnter DOB(yyyy-mm-dd):");
		logger.info("enter DOB");

		String date=scanner.next();
		
		SimpleDateFormat dateFormat=new SimpleDateFormat("dd-mm-yyyy");

		try {
			datex=dateFormat.parse(date);
			flag=false;
			}
		catch(ParseException e) {
		 	System.out.println("Enter valid Data in Specified Format");
		 	logger.error(e);
		}
		}
		while(flag);
		////////
		
		int passYear=0;
		boolean validyearofPass=false;
		do {
			try {
		System.out.println("Enter year of passing:");
		logger.info("enter passing");

		passYear=scanner.nextInt();
		validyearofPass=validator.validNumber(passYear);
			}
			catch(Exception w) {
				System.out.println("----Enter in Valid Format---");
				logger.error(w);
			}
		}while(!validyearofPass);
		//////
		
		System.out.println("Years of Experience:");
		logger.info("enter Years of Experience");

		int experience=scanner.nextInt();
		System.out.println("Enter Address:");
		logger.info("enter Address");

		String address=scanner.next();
		
		System.out.println("Enter qualification:");
		logger.info("enter qualification");

		String qualification=scanner.next();

		System.out.println("Enter Skills:");
		logger.info("enter Skills");

		List<String> skills=new ArrayList<String>();
		
		String choice;
		int ichoice=0;
		boolean stat=false;
		System.out.println("\n1.Java\n2.SQL\n3.Data Science\n4.Testing\n5.Exit");
		do {
			
			do {
		choice=scanner.next();
			try {
				ichoice=Integer.parseInt(choice);
				//stat=false;
				}
			catch(Exception e) {
				stat=true;
				System.out.println("Invalid Option!!! \nSelect Valid SKill\nEnter Skills:");
				logger.error(e);
				}
			   }while(stat);

		
		switch(ichoice) {
		case 1:skills.add("java");
				break;
		case 2:skills.add("sql");
				break;
		case 3:skills.add("data science");
				break;
		case 4:skills.add("testing");
				break;
		case 5: break;
			}
		
		}while(ichoice!=5);
		
		///////
		String email;
		
		do {
			
		System.out.println("Enter email:");
		logger.info("enter email");

		email=scanner.next();
		flag=validator.validEmail(email);
		}
		while(!flag);
		///////////////
		
		System.out.println("Enter Phone Number:");
		logger.info("enter Phone Number");

		String phone;
		phone=scanner.next();
		
		
		System.out.println("Enter graduation percentage:");
		logger.info("enter graduation percentage");

		String percString=scanner.next();
		float percentagef=Float.parseFloat(percString);
		//float percentage=scanner.nextFloat();
		
		System.out.println("Enter username:");
		logger.info("enter username");

		String uname=scanner.next();
		
		System.out.println("Enter password:");
		logger.info("enter password");

		String password=scanner.next();
		
		/*
		 * Jobseeker Table Schema
		 * 
		 * Name            Null     Type         
		--------------- -------- ------------ 
		FIRST_NAME      NOT NULL VARCHAR2(40) 
		MIDDLE_NAME     NOT NULL VARCHAR2(40) 
		LAST_NAME       NOT NULL VARCHAR2(40) 
		DATE_OF_BIRTH   NOT NULL DATE         
		PHONE_NUMBER             VARCHAR2(40) s
		QUALIFICATION   NOT NULL VARCHAR2(40) 
		EMAIL_ID        NOT NULL VARCHAR2(40) 
		YEAR_OF_PASSING NOT NULL NUMBER(4)    
		JOB_ID          NOT NULL NUMBER       
		GRADPERCENTAGE  NOT NULL NUMBER(4,2)  
		EXPERIENCE               NUMBER(2)
		 */

		JobseekerModel jmodel=new JobseekerModel(firstName,middleName,lastName,datex,passYear,experience,address,qualification,email,phone,percentagef,uname,password,skills);
		
		JobseekerController newjs=new JobseekerController();
		jobs_id=newjs.registerJobSeeker(jmodel);
		
		mainMenu();
		//loginJobSeeker();
		}
	
	public void loginJobSeeker() {

		logger.info("--- In jobseekerview loginJobSeeker method called---");
		AuthenticationView authView=new AuthenticationView();
		boolean b=authView.main(1);
		if(b)
			MenuAfterLogin();
		else
			System.out.println("\n Invalid UserName or Password \n Enter Valid Credentials:");
		logger.info("Invalid UserName or Password \\n Enter Valid Credentials:");
		
	}

	public void MenuAfterLogin() {
		Scanner s=new Scanner(System.in);
		System.out.println("\n1.Apply for Job\n2.View Job Application Status\n3.log out");
		int choice=s.nextInt();
		switch(choice) {
		case 1:applyJob();
				break;
		case 2:viewStatus();
				break;	
		case 3:VRPSHome homeObj=new VRPSHome();
				homeObj.main(null);
				break;
			
		default:System.out.println("----------Invalid Choice-------\n ----"
				+ ">>>> Enter a Valid Choice:------");
		logger.info("Invalid Choice Enter a Valid Choice:--");
		}
		
	}
	
	public void applyJob() {
		logger.info("--- In jobseekerview applyJob method called---");
		JobseekerValidation validator=new JobseekerValidation(); 
		
//////////////////////
String firstName;
boolean validfirstName=false;
do {
System.out.print("First Name:");
logger.info("enter firstname");

firstName=scanner.next();
validfirstName=validator.validString(firstName);

if(validfirstName==false)
System.out.print("-------------Enter name in Alphabets only-------------\n");
}
while(!validfirstName);

////////////////////////////
String middleName;
boolean validmiddleName=false;
do {
System.out.print("Middle Name:");
logger.info("enter middlename");

middleName=scanner.next();
validmiddleName=validator.validString(firstName);

if(validmiddleName==false)
System.out.print("-------------Enter name in Alphabets only-------------\n");
}
while(!validmiddleName);
////////////////////////////


String lastName;
boolean validlastName=false;
do {
System.out.print("Last Name:");
logger.info("enter lastname");

lastName=scanner.next();
validlastName=validator.validString(firstName);

if(validlastName==false)
System.out.print("-------------Enter name in Alphabets only-------------\n");
}
while(!validlastName);


////////////////////////////
Date datex=null;		
do {
System.out.println("\nEnter DOB(dd-mm-yyyy):");
logger.info("enter DOB");

String date=scanner.next();

SimpleDateFormat dateFormat=new SimpleDateFormat("dd-mm-yyyy");

try {
	datex=dateFormat.parse(date);
	flag=false;
	}
catch(ParseException e) {
	System.out.println("Enter valid Data in Specified Format");
	logger.error(e);
}
}
while(flag);
////////
		///////
int passYear;
boolean validyearofPass;
do {
	
System.out.println("Enter year of passing:");
logger.info("enter yearofpassing");

passYear=scanner.nextInt();
validyearofPass=validator.validNumber(passYear);
}while(!validyearofPass);
//////

System.out.println("Years of Experience:");
logger.info("enter yearofexperience");

int experience=scanner.nextInt();

System.out.println("Enter Address:");
logger.info("enter address");

String address=scanner.next();

System.out.println("Enter qualification:");
logger.info("enter qualification");

String qualification=scanner.next();

System.out.println("Enter Skills:");
logger.info("enter skills");

List<String> skills=new ArrayList<String>();

String choice;
int ichoice=0;
boolean stat=false;
System.out.println("\n1.Java\n2.SQL\n3.Data Science\n4.Testing\n5.Exit");
do {
	
	do {
choice=scanner.next();
	try {
		ichoice=Integer.parseInt(choice);
		//stat=false;
		}
	catch(Exception e) {
		stat=true;
		System.out.println("Invalid Option!!! \nSelect Valid SKill\nEnter Skills:");
		logger.error(e);
		}
	   }while(stat);


switch(ichoice) {
case 1:skills.add("java");
		break;
case 2:skills.add("sql");
		break;
case 3:skills.add("data science");
		break;
case 4:skills.add("testing");
		break;
case 5: break;
	}

}while(ichoice!=5);

///////
String email;

do {
	
System.out.println("Enter email:");
logger.info("enter email");

email=scanner.next();
flag=validator.validEmail(email);
}
while(!flag);
///////////////

System.out.println("Enter Phone Number:");
logger.info("enter phonenumber");

String phone;
phone=scanner.next();


System.out.println("Enter graduation percentage:");
logger.info("enter graduation percentage");

String percString=scanner.next();
float percentagef=Float.parseFloat(percString);
//float percentage=scanner.nextFloat();
		System.out.println("Enter jobpostId:");
		logger.info("enter jobpostid");

		int jobpostId=scanner.nextInt();
		ApplicationModel application=new ApplicationModel
				(firstName,middleName,lastName,datex,phone,qualification,email
						,passYear,jobpostId,percentagef,experience,address,skills);
		
		// passing Application to Admin, then forwaded to TR and then to HR
		// october 5,overriden above comment--------- store in DAO of applications and then view all applications to employee's for shortlisting
		
		//application
		//ApplicationShortlistController AdminObj=new ApplicationShortlistController();
		//AdminObj.AdminSLController();
		
		//ApplicationShortlist adminselection=new ApplicationShortlist();
		//adminselection.AdminShortList(application);
	
		ApplicationController app=new ApplicationController();
		app.AppliedApplication(application);

	
	}
	
	
	public void viewStatus() {
		logger.info("--- In jobseekerview viewstatus method called---");
		System.out.println("Enter Reference ID:");
		int refId=scanner.nextInt();
		JobseekerController jcontroller=new JobseekerController();
		jcontroller.viewStatus(refId);
		
		
	}
}
 