package com.virtusa.helper;

public class FactoryAdminHelper {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
