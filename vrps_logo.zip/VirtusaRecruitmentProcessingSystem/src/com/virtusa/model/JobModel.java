package com.virtusa.model;

import java.util.List;

import org.apache.log4j.Logger;

/*
 * JOB_ID                NOT NULL NUMBER(10)   
DESIGNATION           NOT NULL VARCHAR2(40) 
REQUIRED_EXPERIENCE            NUMBER(2)    
REQUIRED_SKILLS                VARCHAR2(40) 
ELIGIBILITYPERCENTAGE          NUMBER(2,2) 
 */
public class JobModel {
	Logger logger=Logger.getLogger(JobModel.class.getName());
	private int jobId;
	private String designation;
	private int experience;
	private double eligibilityPercentage;
	private List<String> skills;

	
	public JobModel() {}
	
	public JobModel(int jobId,  String designation,int experience, double eligibilityPercentage, List<String> skills) 
	{
		logger.info("--- In JobModel JobModel method called---");
		this.jobId = jobId;
		this.designation = designation;
		this.experience=experience;
		this.eligibilityPercentage = eligibilityPercentage;
		this.skills = skills;
	}

	
	
	public int getJobId() {
		logger.info("--- In JobModel getJobId method called---");

		return jobId;
	}
	public void setJobId(int jobId) {
		logger.info("--- In JobModel setJobId method called---");

		this.jobId = jobId;
	}

	public String getDesignation() {
		logger.info("--- In JobModel getDesignation method called---");

		return designation;
	}
	public void setDesignation(String desgination) {
		logger.info("--- In JobModel setDesignation method called---");

		this.designation = desgination;
	}
	public double geteligibilityPercentage() {
		logger.info("--- In JobModel geteligibilityPercentage method called---");

		return eligibilityPercentage;
	}
	public void seteligibilityPercentage(double eligibilityPercentage) {
		logger.info("--- In JobModel seteligibilityPercentage method called---");

		this.eligibilityPercentage = eligibilityPercentage;
	}
	public List<String> getSkills() {
		logger.info("--- In JobModel getSkills method called---");

		return skills;
	}
	public void setSkills(List<String> skills) {
		logger.info("--- In JobModel setSkills method called---");

		this.skills = skills;
	}

	public int getExperience() {
		logger.info("--- In JobModel getExperience method called---");

		return experience;
	}

	public void setExperience(int experience) {
		logger.info("--- In JobModel setExperience method called---");

		this.experience = experience;
	}
	
	
	

}
