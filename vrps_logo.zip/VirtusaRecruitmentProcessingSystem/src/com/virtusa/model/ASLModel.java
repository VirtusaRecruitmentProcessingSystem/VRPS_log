package com.virtusa.model;

import org.apache.log4j.Logger;

public class ASLModel {
	Logger logger=Logger.getLogger(ASLModel.class.getName());
	private int jobseekerId;
	private  int jobpostId ;
	private String adminStatus;
	private String trStatus;
	private String hrStatus;
	
	public ASLModel(int jobseekerId,String adminStatus,String trStatus, String hrStatus) {
		logger.info("--- In ASLModel ASLModel method called---");
		this.adminStatus=adminStatus;
		this.jobseekerId = jobseekerId;
		this.trStatus = trStatus;
		this.hrStatus = hrStatus;
		
		
	}
	
	public ASLModel(int jobpostId,int jobseekerId,String adminStatus,String trStatus, String hrStatus) {
		logger.info("--- In ASLModel ASLModel method called  ---");
		this.adminStatus=adminStatus;
		this.jobseekerId = jobseekerId;
		this.trStatus = trStatus;
		this.hrStatus = hrStatus;
		this.jobpostId = jobpostId;
		
	}
	
	public int getJobseekerId() {
		logger.info("--- In ASLModel getJobseekerId method called---");

		return jobseekerId;
	}
	public void setJobseekerId(int jobseekerId) {
		logger.info("--- In ASLModel setJobseekerId method called---");

		this.jobseekerId = jobseekerId;
	}
	public int getJobpostId() {
		logger.info("--- In ASLModel getJobpostId method called---");

		return jobpostId;
	}
	public void setJobpostId(int jobpostId) {
		logger.info("--- In ASLModel setJobpostId method called---");

		this.jobpostId = jobpostId;
	}
	public String getAdminStatus() {
		logger.info("--- In ASLModel getAdminStatus method called---");

		return adminStatus;
	}
	public void setAdminStatus(String adminStatus) {
		logger.info("--- In ASLModel setAdminStatus method called---");

		this.adminStatus = adminStatus;
	}
	public String getTrStatus() {
		logger.info("--- In ASLModel getTrStatus method called---");

		return trStatus;
	}
	public void setTrStatus(String trStatus) {
		logger.info("--- In ASLModel setTrStatus method called---");

		this.trStatus = trStatus;
	}
	public void setHrStatus(String hrStatus) {
		logger.info("--- In ASLModel setHrStatus method called---");

		this.hrStatus = hrStatus;
	}
	

	
}
