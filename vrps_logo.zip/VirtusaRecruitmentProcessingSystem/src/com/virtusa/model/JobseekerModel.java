package com.virtusa.model;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

public class JobseekerModel {
	Logger logger=Logger.getLogger(JobseekerModel.class.getName());
	private String fname;
	private String mname;
	private String lname;
	private Date datex;
	private int passYear;
	private int experience;
	private String address;
	private String qualification;
	private String email;
	private String phone;
	private float percentage;
	private String uname;
	private String password;
	private List<String> skills;

	
	public List<String> getSkills() {
		logger.info("--- In JobseekerModel getSkills method called---");
		return skills;
	}



	public void setSkills(List<String> skills) {
		logger.info("--- In JobseekerModel getSkills method called---");

		this.skills = skills;
	}



	public JobseekerModel(String fname, String mname, String lname, Date datex, int passYear, int experience,
			String address, String qualification, String email, String phone, float percentage, String uname,
			String password,List<String> skills) {
		logger.info("--- In JobseekerModel JobseekerModel method called---");

		// TODO Auto-generated constructor stub
		this.fname=fname;
		this.mname=mname;
		this.address=address;
		this.datex=datex;
		this.email=email;
		this.experience=experience;
		this.lname=lname;
		this.password=password;
		this.phone=phone;
		this.qualification=qualification;
		this.uname=uname;
		this.skills=skills;
		this.percentage=percentage;
		this.passYear=passYear;
	
	
	
	}



	public String getFname() {
		logger.info("--- In JobseekerModel getFname method called---");

		return fname;
	}



	public String getMname() {
		logger.info("--- In JobseekerModel getMname method called---");

		return mname;
	}



	public String getLname() {
		logger.info("--- In JobseekerModel getLname method called---");

		return lname;
	}



	public Date getDatex() {
		logger.info("--- In JobseekerModel getDatex method called---");

		return datex;
	}



	public int getPassYear() {
		logger.info("--- In JobseekerModel getPassYear method called---");

		return passYear;
	
	}



	public int getExperience() {
		logger.info("--- In JobseekerModel getExperience method called---");

		return experience;
	}



	public String getAddress() {
		logger.info("--- In JobseekerModel getAddress method called---");

		return address;
	}



	public String getQualification() {
		logger.info("--- In JobseekerModel getQualification method called---");

		return qualification;
	}



	public String getEmail() {
		logger.info("--- In JobseekerModel getEmail method called---");

		return email;
	}



	public String getPhone() {
		logger.info("--- In JobseekerModel getSgetPhonekills method called---");

		return phone;
	}



	public float getPercentage() {
		logger.info("--- In JobseekerModel getPercentage method called---");

		return percentage;
	}



	public String getUname() {
		logger.info("--- In JobseekerModel getUname method called---");

		return uname;
	}



	public String getPassword() {
		logger.info("--- In JobseekerModel getPassword method called---");

		return password;
	}




}
