package com.virtusa.model;
import org.apache.log4j.Logger;

import com.vrps.authentication.UserAuthentication;
public class LoginModel {
	Logger logger=Logger.getLogger(LoginModel.class.getName());
String username;
String password;

	public LoginModel(String username,String password) {
		
		this.username=username;
		this.password=password;
	//	userAuthentication(username,password);
	}

	
	public String getUsername() {
		logger.info("--- In AdminDAO getUsername method called---");
		return username;
	}

	public String getPassword() {
		logger.info("--- In AdminDAO getPassword method called---");
		return password;
	
	}
	

}