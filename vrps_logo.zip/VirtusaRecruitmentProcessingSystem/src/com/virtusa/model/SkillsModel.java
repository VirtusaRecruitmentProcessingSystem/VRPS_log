package com.virtusa.model;

import java.util.List;

import org.apache.log4j.Logger;

import java.util.ArrayList;

public class SkillsModel {
	Logger logger=Logger.getLogger(SkillsModel.class.getName());
	String s;
	List<String> skills=new ArrayList<>();
	public void setSkill(String s) {
		logger.info("--- In SkillsModel setSkill method called---");
		this.s=s;
		skills.add(s);
	}
	public void getSkill() {
		logger.info("--- In SkillsModel getSkill method called---");
		for(int i=0;i<skills.size();i++){
		return;
		//return s;
	}
}
}