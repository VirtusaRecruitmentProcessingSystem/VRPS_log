package com.virtusa.validation;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

public class JobseekerValidation {
	Logger logger=Logger.getLogger(JobseekerValidation.class.getName());
public boolean validString(String val) {
	logger.info("--- In JobseekerValidation validString method called---");
		boolean result=false;
		char chars[]=val.toCharArray();
		List<Character> alphabets=new ArrayList<>();
		for(int i=97;i<=122;i++) {
			alphabets.add((char)i);
		}
		
		for(char ch:chars) {
			if(alphabets.contains(ch))
				result=true;
			else if(!(alphabets.contains(ch)))
				result=false;
							}		
	return result;
	}

	public boolean validNumber(int number) {
		logger.info("--- In JobseekerValidation validNumber method called---");

		boolean result=false;
		String data=String.valueOf(number);
		if(data.matches(".*[0-9]")) {
			return true;
		}
		else
			return false;
		
	}
	
	public boolean validSalary(double salary) {
		logger.info("--- In JobseekerValidation validSalary method called---");

		boolean result=false;
		String salaryVal=String.valueOf((int)salary);
		if(salary>0 && salaryVal.length()<=5) {
			result=true;
		}
		return result;
}
	
	public boolean validEmail(String email) {
		logger.info("--- In JobseekerValidation validEmail method called---");

		boolean result=false;
		if(email.matches("^(.+)@(.+)$")) {
			result=true;
		}
		return result;
	}
	
	public boolean validPhoneNumber(String PhoneNo) {
		logger.info("--- In JobseekerValidation validPhoneNumber method called---");

		boolean lenValidity=false,typeValidity=false;
		
		if(PhoneNo.length()!=10) {
			System.out.println("-----Enter a Valid 10 Digit Mobile Number---");
			lenValidity=false;
		}
		else
			lenValidity=true;
		char ch;
		for(int i=0;i<PhoneNo.length();i++) {
			ch=PhoneNo.charAt(i);
			if(Character.isDigit(ch)!=true) 
				typeValidity=false;
			else
				typeValidity=true;
		}
		if(lenValidity && typeValidity)
			return true;
		else
			return false;
	}
	
}
