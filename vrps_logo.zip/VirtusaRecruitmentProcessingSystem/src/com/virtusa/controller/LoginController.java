package com.virtusa.controller;

import org.apache.log4j.Logger;

import com.vrps.authentication.UserAuthentication;

public class LoginController {
	Logger logger=Logger.getLogger(LoginController.class.getName());

	public boolean userAuthentication(String username,String password,int option) {
		logger.info("---In LoginController userAuthentication method is called---");

	UserAuthentication userAuth=new UserAuthentication();
	boolean result1=userAuth.Verification(username, password,option);
	logger.info("--userAuthentication method completed--");

		return result1;
	
	}
}
