package com.virtusa.controller;

import org.apache.log4j.Logger;

import com.virtusa.model.ApplicationModel;
import com.virtusa.model.JobseekerModel;
import com.virtusa.services.JobServiceImpl;
import com.virtusa.services.JobseekerServicesImpl;

public class JobseekerController {
	Logger logger=Logger.getLogger(JobseekerController.class.getName());


	int jobs_id;
public int registerJobSeeker(JobseekerModel model) {
	logger.info("---In JobseekerController registerJobSeeker method is called---");

	JobseekerServicesImpl register=new JobseekerServicesImpl();
 	jobs_id=register.JobseekerRegistration(model);
	logger.info("--registerJobSeeker method completed--");

 	return jobs_id;

}


public void loginJobseeker(JobseekerModel model) {
	
	
	
}
public void jobApplication(ApplicationModel applicationModel) {
	logger.info("---In JobseekerController jobApplication method is called---");

	JobServiceImpl jobobj=new JobServiceImpl(); 
	
	logger.info("--jobApplication method completed--");


}

public void viewStatus(int refId) {
	logger.info("---In JobseekerController viewStatus method is called---");

	JobseekerServicesImpl statusServiceobj=new JobseekerServicesImpl();
	statusServiceobj.viewStatus(refId);
	logger.info("--viewStatus method completed--");

}

}
