package com.virtusa.controller;

import java.util.List;

import org.apache.log4j.Logger;

import com.virtusa.helper.FactoryTrHelper;

import com.virtusa.model.JobseekerModel;

import com.virtusa.services.TRServices;

import com.virtusa.services.TRservicesImpl;
import com.virtusa.ui.VRPSHome;
import com.virtusa.view.JobseekerView;
import com.virtusa.view.TRView;

public class TRController
{
	Logger logger=Logger.getLogger(TRController.class.getName());

		private TRServices trServices;
		public TRController() 
		{
			this.trServices=FactoryTrHelper.createTRService();
		}
		
			public  void getAllJobSeekers() {
				logger.info("---In TRController getAllJobSeekers method is called---");

				TRView trview=new TRView();
				List<JobseekerModel> model1=trServices.getAllJobSeekers();
				TRServices trservicesimp=new TRservicesImpl();
				trservicesimp.getAllJobSeekers();
				logger.info("--getAllJobSeekers method completed--");

			}

			public  void TrShortlist() {
				logger.info("---In TRController TrShortlist method is called---");
				// TODO Auto-generated method stub
				TRServices trstatus=new TRservicesImpl();
				logger.info("--TrShortlist method completed--");

//				trstatus.updateTrStatus();
			
			}

			public  void rate_comment() {
				logger.info("---In TRController rate_comment method is called---");

				// TODO Auto-generated method stub
				TRServices rateandcomment=new TRservicesImpl();
				rateandcomment.rate_comment();
				logger.info("--rate_comment method completed--");

			}
		//

}
