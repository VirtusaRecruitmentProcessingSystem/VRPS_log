package com.virtusa.controller;

import org.apache.log4j.Logger;

import com.virtusa.model.ApplicationModel;
import com.virtusa.services.ApplicationServices;

public class ApplicationController {
	//ApplicationModel application
	Logger logger=Logger.getLogger(ApplicationController.class.getName());

	public void AppliedApplication(ApplicationModel application) {
		logger.info("---In ApplicationController AppliedApplication method is called---");

		ApplicationServices appservices=new ApplicationServices();
		appservices.AppliedApplicationService(application);
	}
	
	public void AdminSLController() {
		ApplicationServices SLService=new ApplicationServices();
		SLService.AdminShortlistServices();//application
				
	}
	
	
	
	public void TRSLController() {
		ApplicationServices TRSLService=new ApplicationServices();
		TRSLService.AdminShortlistServices();
	}

	
public void HRSLController() {
	ApplicationServices HRSLService=new ApplicationServices();
	HRSLService.AdminShortlistServices();
}



}