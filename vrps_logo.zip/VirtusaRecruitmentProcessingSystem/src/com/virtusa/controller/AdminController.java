package com.virtusa.controller;

import org.apache.log4j.Logger;

import com.virtusa.model.LoginModel;
import com.virtusa.services.AdminServices;
import com.virtusa.services.AdminServicesImpl;
import com.virtusa.services.ApplicationServices;
import com.vrps.authentication.UserAuthentication;

public class AdminController {
	Logger logger=Logger.getLogger(AdminController.class.getName());

	AdminServicesImpl adminservice=new AdminServicesImpl();
	ApplicationServices adminapp=new ApplicationServices();

	public void addJobPost() {
		logger.info("---In admincontroller addJobPost method is called---");
		adminservice.addJobPost();
		logger.info("--addJobPost method completed--");
	}
	public void deleteJobPost() {
		logger.info("---In admincontroller deleteJobPost method is called---");
		adminservice.deleteJobPost();
		logger.info("--deleteJobPost method completed--");
	}

	public void rate_comment() {
		logger.info("---In admincontroller rate_comment method is called---");
		adminservice.rate_comment();
		logger.info("--rate_comment method completed--");
	}

	public void shortlistCandidates() {
		logger.info("---In admincontroller shortlistCandidates method is called---");
		//	adminservice.shortlistCandidates();
		adminapp.AdminShortlistServices();
		logger.info("--shortlistCandidates method completed--");

	}

	//public void addResource() {
	// TODO Auto-generated method stub
	//adminservice.addResource();
	//}




}
